# Image Credits

This v26 package uses only assets that are referenced by the current static website build.

## Brand and Owned Materials

- Official complete Rain Education logo: `assets/logo.png`
- Optimized complete logo derivative for web delivery: `assets/logo-optimized.webp`
- 192px favicon / app icon: `assets/logo-mark-192.png`
- Mentor portraits, QR codes, and anonymized offer images: Rain Education-owned or user-provided project materials.

## Hero Image

- Hong Kong Victoria Harbour hero image: `assets/bg-hong-kong-clear-v10.webp`, retained from the approved no-video website asset set and delivered as WebP for first-screen performance.

## Performance Note

Unused historical backgrounds, duplicated PNG/WebP pairs, cultural gallery images, CV extracts, old video-related source images, and previous-version decorative assets were removed from the v26 deployment package.
